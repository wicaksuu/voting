<x-guest-layout>
    <br><br><br><br><br><br><br><br><br><br><br><br>
    <div class="p-3">
        @livewire('juri-vote')
    </div>
</x-guest-layout>