<x-guest-layout>
    <br><br><br><br><br><br><br><br><br><br><br><br>
    <div class="p-3">
        @livewire('user-vote')
    </div>
</x-guest-layout>