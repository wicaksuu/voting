<?php return array (
  'admin' => 'App\\Http\\Livewire\\Admin',
  'juri-vote' => 'App\\Http\\Livewire\\JuriVote',
  'tabel-peserta' => 'App\\Http\\Livewire\\TabelPeserta',
  'user-vote' => 'App\\Http\\Livewire\\UserVote',
);