<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <br><br><br><br><br><br><br><br><br><br><br><br>
    <div class="p-3">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('juri-vote')->html();
} elseif ($_instance->childHasBeenRendered('lKoDLvr')) {
    $componentId = $_instance->getRenderedChildComponentId('lKoDLvr');
    $componentTag = $_instance->getRenderedChildComponentTagName('lKoDLvr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lKoDLvr');
} else {
    $response = \Livewire\Livewire::mount('juri-vote');
    $html = $response->html();
    $_instance->logRenderedChild('lKoDLvr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?><?php /**PATH /media/wicaksu/DATA/Kantor/Diskominfo/vote-nyanyi/resources/views/vote-juri.blade.php ENDPATH**/ ?>