<?php
$i=0;
?>
<?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$i++;
?>
<tr class="bg-white border-b">
    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e($i); ?>

    </td>
    <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
        <?php echo e($pesetas->nama); ?>

    </td>
    <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
        <?php echo e($pesetas->kategori); ?>

    </td>
    <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
        <?php echo e($pesetas->status); ?>

    </td>
    <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
        <?php echo e($pesetas->status); ?>

    </td>
</tr class="bg-white border-b">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /media/wicaksu/DATA/Kantor/Diskominfo/vote-nyanyi/resources/views/livewire/tabel-peserta.blade.php ENDPATH**/ ?>