<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="pt-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin')->html();
} elseif ($_instance->childHasBeenRendered('V6WcoYb')) {
    $componentId = $_instance->getRenderedChildComponentId('V6WcoYb');
    $componentTag = $_instance->getRenderedChildComponentTagName('V6WcoYb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('V6WcoYb');
} else {
    $response = \Livewire\Livewire::mount('admin');
    $html = $response->html();
    $_instance->logRenderedChild('V6WcoYb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
    <div class="pt-5">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-3">
                <div class="flex flex-col">
                    <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="py-4 inline-block min-w-full sm:px-6 lg:px-8">
                            <div class="overflow-hidden">
                                <table class="min-w-full text-center">
                                    <thead class="border-b bg-gray-800">
                                        <tr>
                                            <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                                No
                                            </th>
                                            <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                                Nama Peserta
                                            </th>
                                            <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                                Kategori
                                            </th>
                                            <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                                Status
                                            </th>
                                            <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                                Point
                                            </th>
                                        </tr>
                                    </thead class="border-b">
                                    <tbody>
                                        <div wire:poll>
                                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tabel-peserta')->html();
} elseif ($_instance->childHasBeenRendered('dwBedBq')) {
    $componentId = $_instance->getRenderedChildComponentId('dwBedBq');
    $componentTag = $_instance->getRenderedChildComponentTagName('dwBedBq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dwBedBq');
} else {
    $response = \Livewire\Livewire::mount('tabel-peserta');
    $html = $response->html();
    $_instance->logRenderedChild('dwBedBq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                        </div>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /media/wicaksu/DATA/Kantor/Diskominfo/vote-nyanyi/resources/views/dashboard.blade.php ENDPATH**/ ?>