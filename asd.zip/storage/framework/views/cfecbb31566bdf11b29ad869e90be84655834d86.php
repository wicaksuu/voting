<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <br><br><br><br><br><br><br><br><br><br><br><br>
    <div class="p-3">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-vote')->html();
} elseif ($_instance->childHasBeenRendered('L1b9avP')) {
    $componentId = $_instance->getRenderedChildComponentId('L1b9avP');
    $componentTag = $_instance->getRenderedChildComponentTagName('L1b9avP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('L1b9avP');
} else {
    $response = \Livewire\Livewire::mount('user-vote');
    $html = $response->html();
    $_instance->logRenderedChild('L1b9avP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?><?php /**PATH /media/wicaksu/DATA/Kantor/Diskominfo/vote-nyanyi/resources/views/vote.blade.php ENDPATH**/ ?>